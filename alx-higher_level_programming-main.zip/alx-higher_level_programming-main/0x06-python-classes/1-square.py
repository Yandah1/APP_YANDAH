#!/usr/bin/python3

"""class Square that defines a square by: (based on 0-square.py)"""


class Square:
    """Define class and  Private instance attribute: size"""

    def __init__(self, size):
        self.__size = size    # Private instance attribute: size
