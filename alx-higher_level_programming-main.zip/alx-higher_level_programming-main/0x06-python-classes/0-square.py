#!/usr/bin/python3

"""Write an empty class Square that defines a square:"""


class Square:
    """defines empty class."""

    pass
