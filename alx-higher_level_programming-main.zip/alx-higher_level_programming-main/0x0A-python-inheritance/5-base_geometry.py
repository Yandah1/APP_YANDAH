#!/usr/bin/python3
"""create empty class named BaseGeometry"""


class BaseGeometry:
    """Represent  base geometry"""
    pass
