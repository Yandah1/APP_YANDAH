#!/usr/bin/python3

"""Raise a TypeError exception."""


def raise_exception():
    raise TypeError
