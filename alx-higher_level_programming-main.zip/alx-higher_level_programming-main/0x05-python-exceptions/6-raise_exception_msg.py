#!/usr/bin/python3

"""Raise a NameError exception with a message."""


def raise_exception_msg(message=""):
    raise NameError(message)
