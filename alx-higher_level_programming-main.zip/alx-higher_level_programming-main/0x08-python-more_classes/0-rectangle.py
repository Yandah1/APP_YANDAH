#!/usr/bin/python3
"""Defines a Rectangle class."""


class Rectangle:
    """Representing a rectangle."""

    pass
