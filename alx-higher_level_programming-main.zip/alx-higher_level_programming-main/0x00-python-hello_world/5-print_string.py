#!/usr/bin/python3
str = "Holberton School"
characters_to_print = str[:9]
print(str * 3)
print(str[:9])
