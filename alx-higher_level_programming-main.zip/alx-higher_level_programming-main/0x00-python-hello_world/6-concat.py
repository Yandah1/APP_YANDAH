#!/usr/bin/python3
str1 = "Holberton"
str2 = "School"
added_str = f"{str1} {str2}"
print(f"Welcome to {added_str}!")
