#!/usr/bin/python3
print("The Zen of Python, by Tim Peters")
