#!/usr/bin/python3
import sys
text = "and that piece of art is useful - Dora Korpar, 2015-10-19"
sys.stderr.write(text + '\n')
sys.exit(1)
