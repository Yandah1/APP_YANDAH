This is my first repo on python with ALX. 

0x00. Python - Hello, World
 Python Project
This is a simple Python project that prints "Hello, World!" to the console. It serves as a basic introduction to the Python programming language.

0x01. Python - if/else, loops, functions

0x02. Python - import & modules
