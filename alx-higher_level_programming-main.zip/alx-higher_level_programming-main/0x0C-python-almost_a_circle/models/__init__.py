#!/usr/bin/python3
""" Empty  file """
