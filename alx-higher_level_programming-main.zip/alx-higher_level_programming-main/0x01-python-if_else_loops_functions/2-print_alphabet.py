#!/usr/bin/python3
for letter in range(26):
    print("{:s}".format(chr(letter + ord("a"))), end="")
