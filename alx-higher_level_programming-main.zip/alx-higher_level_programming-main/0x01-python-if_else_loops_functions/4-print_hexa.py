#!/usr/bin/python3
for numb in range(99):
    print("{} = {}".format(numb, hex(numb)))
